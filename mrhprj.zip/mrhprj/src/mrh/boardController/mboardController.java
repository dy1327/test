package mrh.boardController;

import java.util.List;

import javax.naming.ldap.Control;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mrh.board.Controller;
import mrh.dao.MboardDao;
import mrh.vo.Mboard;

public class mboardController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("mboardController 신호");
		
		MboardDao dao=new MboardDao();
		List<Mboard> list=dao.getBoards();
		
		request.setAttribute("list", list);
		request.getRequestDispatcher("mboard.jsp").forward(request, response);
		
		
	}


}
