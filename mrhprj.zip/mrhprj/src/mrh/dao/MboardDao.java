package mrh.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import mrh.db.DBCon;
import mrh.vo.Mboard;

public class MboardDao {

	public List<Mboard> getBoards() throws Exception {
		String sql="select * from mrhtbl";
		
		Connection con=DBCon.getConnection();
		
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery();
		
		List<Mboard> list=new ArrayList<Mboard>();
		while (rs.next()) {
			Mboard m=new Mboard();
			m.setMseq(rs.getString("mseq"));
			m.setMtitle(rs.getString("mtitle"));
			m.setMwriter(rs.getString("mwriter"));
			m.setMcontent(rs.getString("mcontent"));
			m.setMregdate(rs.getDate("mregdate"));
			m.setMhit(rs.getInt("mhit"));
			
			list.add(m);
		}
		rs.close();
		pstmt.close();
		con.close();
		
		return list;
		
	}
	
}
